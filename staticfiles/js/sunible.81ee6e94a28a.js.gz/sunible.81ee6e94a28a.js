// Root module
var sunible = (function () {
	var initModule = function ($container) {
		sunible.shell.initModule($container);
	};
	return {initModule: initModule}
}());